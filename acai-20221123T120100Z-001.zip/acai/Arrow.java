package acai;

import java.awt.Color;
import java.awt.Image;

import javax.swing.BorderFactory;

public class Arrow extends IconHolder{
	
	static int w = 30;
	static int h = 30;

	public Arrow() {
		super(w, h);
		c = this.arrowIcon;
		c.setImage(c.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));		
		//setBorder(BorderFactory.createLineBorder(Color.black));
		setOpaque(false);
		init();
	}
	
}
