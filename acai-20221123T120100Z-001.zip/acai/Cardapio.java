package acai;

import java.awt.Image;
import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Cardapio {
	
	ImageIcon copo1 = new ImageIcon(getClass().getResource("/res/copo1.png"));
	ImageIcon coca = new ImageIcon(getClass().getResource("/res/coca.png")),
			  fantal = new ImageIcon(getClass().getResource("/res/fantalaranja.png")),
			  fantau = new ImageIcon(getClass().getResource("/res/fantauva.png")),
			  guarana = new ImageIcon(getClass().getResource("/res/guarana.png")),
		   	  agua = new ImageIcon(getClass().getResource("/res/minalba.png")),
			  pepsi = new ImageIcon(getClass().getResource("/res/pepsi.png")),
			  sprite = new ImageIcon(getClass().getResource("/res/sprite.png")),
			  coxinha = new ImageIcon(getClass().getResource("/res/coxinha.png")),
			  empadinha = new ImageIcon(getClass().getResource("/res/empadinha.png")),
			  enroladinho = new ImageIcon(getClass().getResource("/res/enroladinho.png")),
			  kibe = new ImageIcon(getClass().getResource("/res/kibe.png")),
			  pastelzinho = new ImageIcon(getClass().getResource("/res/pastelzinho.png"));

	public ItemRow[] list = {new ItemRow(Window.ACAI, "Açaí", copo1), new ItemRow(Window.BEBIDA, "Coca-Cola", coca), new ItemRow(Window.BEBIDA, "Fanta Laranja", fantal),
							 new ItemRow(Window.BEBIDA, "Fanta Uva", fantau), new ItemRow(Window.BEBIDA, "Guaraná", guarana), new ItemRow(Window.BEBIDA, "Água", agua),
							 new ItemRow(Window.BEBIDA, "Pepsi", pepsi), new ItemRow(Window.BEBIDA, "Sprite", sprite), new ItemRow(Window.SALGADO, "Coxinha", coxinha),
							 new ItemRow(Window.SALGADO, "Empadinha", empadinha), new ItemRow(Window.SALGADO, "Enroladinho", enroladinho), new ItemRow(Window.SALGADO, "Kibe", kibe),
							 new ItemRow(Window.SALGADO, "Pastelzinho", pastelzinho)};
	/*
	 * 0  açai
	 * 1  coca
	 * 2  fanta laranja
	 * 3  fanta uva
	 * 4  guarana
	 * 5  agua
	 * 6  pepsi
	 * 7  sprite
	 * 8  coxinha
	 * 9  empadinha
	 * 10 enroladinho
	 * 11 kibe
	 * 12 pastelzinho
	 */
	Cardapio(){
		for(ItemRow ir : list) ir.ih.removeMouseListener(ir.ih.ml);
		list[0].description.setText("Customize seu açaí!");
		list[0].description.setBounds(94, 50);
		list[1].nodescription();
		
		int[] a = {1,3,4,5,6,7};
		int[][] s = {{70,70},{80,60},{80,80},{80,80},{68,68},{75,75}};
		for(int i = 0; i < a.length; i++) {
			list[a[i]].nodescription();
			list[a[i]].ih.c.setImage(list[a[i]].ih.c.getImage().getScaledInstance(s[i][0], s[i][1], 4));
		}
		
		list[2].nodescription();
		
		int[] prices = {0,5,5,5,4,4,5,5,6,5,4,4,3};
		for(int i = 0; i < list.length; i ++) {
			list[i].price = prices[i];
		}
	}

}
