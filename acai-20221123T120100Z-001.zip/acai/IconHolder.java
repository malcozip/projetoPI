package acai;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class IconHolder extends JPanel{
	
	public ImageIcon plusIcon = new ImageIcon(getClass().getResource("/res/plus.png"));
	public ImageIcon copo1 = new ImageIcon(getClass().getResource("/res/copo1.png"));
	public ImageIcon minusIcon = new ImageIcon(getClass().getResource("/res/minus.png"));
	public ImageIcon arrowIcon = new ImageIcon(getClass().getResource("/res/arrow2.png"));
	public ImageIcon leitemoca = new ImageIcon(getClass().getResource("/res/leitemoca.png"));
	public ImageIcon leiteninho = new ImageIcon(getClass().getResource("/res/leiteninho.png"));
	public ImageIcon banana = new ImageIcon(getClass().getResource("/res/acaibanana.png"));
	ImageIcon c = new ImageIcon();
	public MouseListener ml = new MouseAdapter() {
		public void mouseEntered(MouseEvent e) {
			if(getFrame()!=null) getFrame().setCursor(new Cursor(Cursor.HAND_CURSOR));
		}
		
		public void mouseExited(MouseEvent e) {
			if(getFrame()!=null) getFrame().setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	};
	JLabel label;
	public int width;
	public int height;
	int size = 0;
	
	JFrame getFrame() { return (JFrame) SwingUtilities.getWindowAncestor(this); }
	
	public IconHolder(int width, int height) {
		if(c.getImage()!=null) c.setImage(c.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
		this.width = width;
		this.height = height;
		setPreferredSize(new Dimension(width, height));
	}
	
	public IconHolder(int s) {
		size = ((s > 100) ? 100 : (s<0) ? 0 : s);
		this.width = (width*size/100)+5;
		this.height = (height*size/100)-5;
		setPreferredSize(new Dimension(width, height));
		if(c.getImage()!=null) c.setImage(c.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
	}
	
	void init() {
		label = new JLabel(c);
		add(label);
		setLayout(null);
		setName("default IconHolder");
		label.setBounds(0, 0, width, height);
		setOpaque(false);
		addMouseListener(ml);
	}
	
	public void setBounds(int x, int y) {
		setBounds(x, y, this.width, this.height);
	}
}
