package acai;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class ItemRow extends JPanel {
	
	int w = 360, h = 100;
	int id = 0;
	double price = 10;
	ImageIcon icon;
	IconHolder ih;
	JPanel iconHolder;
	LPanel nameHolder, description;
	SButton addButton;
	String name = "Teste";
	
	public ItemRow(int n, String t) {
		super();
		this.id = n;
		setLayout(null);
		setOpaque(true);
		setBackground(Window.cinza);
		name = t;
		setBorder(BorderFactory.createLineBorder(Color.black));
		nameHolder = new LPanel(name, 100, 25, LPanel.LEFT);
		//nameHolder.setBorder(BorderFactory.createLineBorder(Color.black));
		nameHolder.setBounds(95, 25);
		nameHolder.setFontSize(20);
		
		description = new LPanel(name, 100, 25, LPanel.LEFT);
		description.setBounds(95,50);
		description.setFontSize(11);
		iconHolder = new JPanel();
		iconHolder.setBounds(10, 10, 80, 80);
		iconHolder.setOpaque(false);
		iconHolder.setBorder(BorderFactory.createLineBorder(Color.black));
		addButton = SButton.plus(11);
		addButton.setBounds(290,23);
		addButton.setName(t + " SButton");
		addButton.addMouseListener(m);
		setName(name);
		add(nameHolder);
		add(iconHolder);
		add(addButton);
		add(description);
		setVisible(true);
	}
	
	public ItemRow(int n, String t, ImageIcon ii) {
		super();
		this.id = n;
		setLayout(null);
		setOpaque(true);
		setBackground(Window.cinza);
		name = t;
		setBorder(BorderFactory.createLineBorder(Color.GRAY));
		nameHolder = new LPanel(name, 150, 25, LPanel.LEFT);
		//nameHolder.setBorder(BorderFactory.createLineBorder(Color.black));
		nameHolder.setBounds(95, 25);
		nameHolder.setFontSize(20);
		description = new LPanel(name, 130, 25, LPanel.LEFT);
		description.setBounds(15,50);
		description.setFontSize(11);
		/*iconHolder = new JPanel();
		iconHolder.setBounds(10, 10, 80, 80);
		iconHolder.setOpaque(false);*/
		ih = new IconHolder(80,80);
		//ih.setBorder(BorderFactory.createLineBorder(Color.black));
		ih.c = ii;
		ii.setImage(ii.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH));
		ih.init();
		ih.setBounds(10,10);
		
		
		addButton = SButton.plus(11);
		addButton.setBounds(290,23);
		addButton.setName(t + " SButton");
		addButton.addMouseListener(m);
		setName(name);
		add(nameHolder);
		//add(iconHolder);
		add(ih);
		add(description);
		add(addButton);
		setVisible(true);
	}
	
	void nodescription() {
		description.setText("");
	}
	
	void description(String t) {
		description.setText(t);	
	}
	
	void setIcon(ImageIcon icon) {
		this.icon = icon;
	}
	
	void setBounds(int x, int y) {
		this.setBounds(x, y, w, h);
	}
	
	MouseListener m = new MouseAdapter() {
		public void mouseEntered(MouseEvent e) {
			setBackground(getBackground().darker());
		}
		
		public void mouseExited(MouseEvent e) {
			setBackground(Window.cinza);
		}
	};
	
}