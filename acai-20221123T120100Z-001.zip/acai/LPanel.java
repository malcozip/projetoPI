package acai;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.LayoutManager;

import javax.swing.*;

public class LPanel extends JPanel{

	JLabel label= new JLabel();
	int w = 0;
	int h = 0;
	
	public static final int LEFT = FlowLayout.LEFT, CENTER = FlowLayout.CENTER, RIGHT = FlowLayout.RIGHT;
	
	private void init(String t, int x, int y) {
		this.w = x;
		this.h = y;
		setLayout(null);
		setOpaque(false);
		label.setText(t);
		label.setForeground(Color.black);
		label.setBounds(0, 0, x, y);
		label.setFont(new Font("Serif Plain", Font.PLAIN, 13));
		add(label);
	}
	
	public LPanel(String t, int x, int y) {
		super();
		init(t, x, y);
	}
	
	public LPanel(String t, int x, int y, int alignment) {
		super(new FlowLayout(alignment));
		init(t, x, y);
		//align(alignment);
	}
	
	void setText(String t) { label.setText(t); }
	
	public void setBounds(int x, int y) { setBounds(x, y, this.w, this.h); }
	
	public void setFontSize(int n) { this.label.setFont(new Font(label.getFont().getFontName(), label.getFont().getStyle(), n)); }
	public void setFontStyle(int n) { this.label.setFont(new Font(label.getFont().getFontName(), n, label.getFont().getSize())); }
	public void setStyle(int n, int m) { this.label.setFont(new Font(label.getFont().getFontName(), n, m)); }
	
	public void align(int n) { this.label.setHorizontalAlignment(n); }

}
