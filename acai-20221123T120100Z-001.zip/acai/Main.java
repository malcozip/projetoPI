package acai;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Main {
	
	static Window frame;

	public static void main(String[] args) {
		frame = new Window();
	}
	
	public Main() {
		
	}
	
	
}

