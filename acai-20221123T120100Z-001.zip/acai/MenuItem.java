package acai;

import javax.swing.JPanel;

public class MenuItem extends JPanel{

	public MenuItem() {
		super();
	}

}
