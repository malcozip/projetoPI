package acai;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MenuLateral extends JPanel {
	
	Celula p1, p2, p3;
	;
	ImageIcon agua = new ImageIcon(getClass().getResource("/res/agua.png")),
					  acai = new ImageIcon(getClass().getResource("/res/copo1.png")),
					  paodequeijo = new ImageIcon(getClass().getResource("/res/paodequeijo.png"));
	String[] pngIds = {"copo1", "agua","paodequeijo"};
	ImageIcon aguaX, acaiX, paodequeijoX;
	ImageIcon[] iconsXF;
	ImageIcon[] icons = {acai, agua, paodequeijo};
	String[] nomes = {"Açaís", "Bebidas", "Salgados"};
	int[][] coor = {
			{100,100,6,22},
			{76,100,5,15},
			{76,65,3,22}
	};
	;
	
	private void init() {
		p1 = new Celula();
		p2 = new Celula();
		p3 = new Celula();
	}
	
	public MenuLateral() {
		super();
		init();
		//setBorder(BorderFactory.createMatteBorder(1, 1, 0, 0, Color.gray));
		setOpaque(false);
		setLayout(null);
		
		ImageIcon[] iconsX = {acaiX, aguaX, paodequeijoX};
		Celula[] a = {p1, p2, p3};
		for(int i = 0; i < a.length; i++) {
			a[i].setName("painelLateral" + i);
			a[i].setBackground(Window.cinza);
			a[i].setBounds(0, 0 + 156 * i, 110, 156);
			a[i].setIndex(i);
			a[i].setLayout(null);
			
			icons[i].setImage(icons[i].getImage().getScaledInstance(coor[i][0], coor[i][1], Image.SCALE_SMOOTH));
			iconsX[i] = new ImageIcon(getClass().getResource("/res/"+pngIds[i]+".png"));
			iconsX[i].setImage(iconsX[i].getImage().getScaledInstance(coor[i][0]+12, coor[i][1]+12, Image.SCALE_SMOOTH));
			a[i].setIcon(icons[i]);
			a[i].icon.setBounds(coor[i][2], coor[i][3], 100, 100);
		
			a[i].setText(nomes[i]);
			a[i].text.setStyle(Font.BOLD, 12);
			a[i].text.setBounds(i==0?40:i==1?33:32, 105);
			
			add(a[i]);
		}
		iconsXF = iconsX;
	}
	
	public JPanel[] getPanels() { return new JPanel[] {p1, p2, p3}; }
	
	public ImageIcon[] getIcons() { return this.icons; }
	public ImageIcon[] getIconsX() { return this.iconsXF; }
	
	public class Celula extends JPanel {
		
		private int index;
		JLabel icon;
		LPanel text;
		
		public Celula() { 
			addMouseListener(m);
			text = new LPanel("", 90, 20, LPanel.CENTER);
			//text.setBorder(BorderFactory.createLineBorder(Color.black));
			add(text);
		}
		public Celula(int n) { super(new FlowLayout(n)); addMouseListener(m); }		
		public void setIcon(ImageIcon icon) { this.icon = new JLabel(icon); add(this.icon); }
		public void setText(String t) { text.setText(t); }
		public void setIndex(int n) { this.index = n; }
		public int getIndex() { return this.index; }
		private JFrame getFrame() { return (JFrame) SwingUtilities.getWindowAncestor(this); }
		
		MouseListener m = new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				setBackground(getBackground().darker());
				getFrame().setCursor(Cursor.HAND_CURSOR);
				icon.setIcon(getIconsX()[getIndex()]);
			}
			
			public void mouseExited(MouseEvent e) {
				setBackground(Window.cinza);
				getFrame().setCursor(Cursor.DEFAULT_CURSOR);
				icon.setIcon(icons[getIndex()]);
			}
		};
	}
	
}