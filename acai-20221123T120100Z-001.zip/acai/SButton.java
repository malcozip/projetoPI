package acai;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class SButton extends IconHolder{

	private ImageIcon plus = this.plusIcon;
	private ImageIcon minus = this.minusIcon;
	
	private final int w = 299;
	private final int h = 375;
	public static final int PLUS = 0;
	public static final int MINUS = 1;
	
	public SButton(int n, int width, int height) {
		super(width, height);
		
		c = (n==0)?plus:minus;
		c.setImage(c.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
		//setPreferredSize(new Dimension(width, height));
		//this.width = width;
		//this.height = height;*/
		init();
		setName("default SButton");
	}
	
	public SButton(int n, int s) {
		super(s);
		
		/*
		int size = ((s > 100) ? 100 : (s<0) ? 0 : s);*/
		this.width = (w*size/100)+5;
		this.height = (h*size/100)-5;
		
		c = (n==0)?plus:minus;
		c.setImage(c.getImage().getScaledInstance(w*s/100, h*s/100, Image.SCALE_SMOOTH));
		//setBorder(BorderFactory.createLineBorder(Color.black));
		init(); 
		label.setIcon(c);
		setName("default SButton");
	}
	
	public static SButton plus() {
		return new SButton(PLUS, 100);
	}
	
	public static SButton plus(int n) {
		return new SButton(PLUS, n);
	}
	
	public static SButton plus(int w, int h) {
		return new SButton(PLUS, w, h);
	}
	
	public static SButton minus() {
		return new SButton(MINUS, 100);
	}
	
	public static SButton minus(int n) {
		return new SButton(MINUS, n);
	}
	
	public static SButton minus(int w, int h) {
		return new SButton(MINUS, w, h);
	}
	
	
	

}