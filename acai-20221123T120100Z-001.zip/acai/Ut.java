package acai;

import java.awt.Component;
import java.awt.Container;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.awt.*;

public class Ut {
	
	static Font font = new Font("Serif Plain", Font.PLAIN, 15);
	static Font font2 = new Font("Serif Plain", Font.ITALIC, 12);
	static Font font3 = new Font("Serif Plain", Font.PLAIN, 12);
	static Font font4 = new Font("Serif Plain", Font.BOLD, 15);

	//public Ut() { }
	
	public static String dec(double d) {
		return String.format("%.1f", d);
	}
	
	public static String dec(double d, int n) {
		return String.format("%." + n + "f", d);
	}
	
	public static String upper(String t) {
		return (t.charAt(0)+"").toUpperCase() + t.substring(1);
	}
	
	public static int toDigit(char c) {
		return Character.getNumericValue(c);
	}
	
	public static int indexOf(int[] a, int o) {
		for(int i = 0; i < a.length; i++) {
			if (a[i]==o) return i;
		}
		return -1;
	}

	public static <T> int indexOf(T[] array, T o) {
		for(int in = 0; in < array.length; in++) {
			if ((o instanceof String) && array[in].equals(o)) return in;
			if (array[in] == o) return in; 
		}
		
		return -1;
	}
	
	public static <T> int indexOf(T[][] array, T[] obj) {
		for(int i = 0; i < array.length; i++) {
			if(obj == array[i]) {
				return i;
			}
		}
		
		return -1;
	}
	
	public static <T extends Container> Component getCompName(T cont, String t) {
		for(Component c : cont.getComponents()) {
			if (c.getName() == null) continue;
			if (c.getName().equals(t)) return c;
		}
		return null;
	}
	
	public static BufferedImage toBufferedImage(Image img)
	{
	    if (img instanceof BufferedImage)
	    {
	        return (BufferedImage) img;
	    }

	    // Create a buffered image with transparency
	    BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

	    // Draw the image on to the buffered image
	    Graphics2D bGr = bimage.createGraphics();
	    bGr.drawImage(img, 0, 0, null);
	    bGr.dispose();

	    // Return the buffered image
	    return bimage;
	}
	
	public static <T> void p(T t) {
		System.out.println(t);
	}
	
	public static int number(String t) {
		for(int i = 0; i < t.length(); i++) {
			if(Character.isDigit(t.charAt(i))) return toDigit(t.charAt(i));
		}
		return -1;
	}
	
	public static int findNumber(String t) {
		int start = 0, end = 0;
		String n = "0";
		boolean doubleWord = 
				(t.length() - t.replace(" ", "").length() >= 3) 
				? true : false;
		boolean noNumber = false;
		for(int i = 0; i <t.replace(" ", "").length();i++) {
			if(Character.isDigit(t.replace(" ", "").charAt(i))) {
				noNumber = true;
				break;
			}
		}
		if(!noNumber) return -1;
		
		if(!doubleWord) {
			if(t.indexOf(' ') != -1) {
				start = t.indexOf(' ');
				end = t.lastIndexOf(' ');		
				n = t.substring(start, end);
				n = n.replace("k", "000");
				n = n.trim();
				if(!n.equals("all")) {
					return Integer.parseInt(n);
				} else {
					return -1;
				}
			} 
		} else {
			if(t.indexOf(' ') != -1) {
				start = t.indexOf(' ');
				for(int i = start + 1; i < t.length(); i++) {
					if(Character.isDigit(start + 1)) {
						if(!Character.isDigit(t.charAt(i)) || t.charAt(i) == ' ')
						{
							p(""+t.charAt(i));
							n = t.substring(start, i);
							n = n.trim();
							break;
						}
					} else if(t.charAt(i) == ' ') {
						p(""+t.charAt(i));
						n = t.substring(start, i);
						n = n.trim();
						break;
					}
				}
				n = n.replace("k", "000");
				if(!n.equals("all")) {
					return Integer.parseInt(n);
				} else {
					return -1;
				}
			} 
		}
		
		return -1;
		
	}
	
	public static String cutNumber(String t) {
		for(char c : t.toCharArray()){
			if(!Character.isDigit(c)) {
				return t.substring(t.indexOf(c));
			}
				
		}
		return t;
	}
	
	public static String findCommand(String t) {
		if(t.indexOf(' ') != -1) {
			return t.substring(0, t.indexOf(' ')).trim();
		} else {
			return t.trim();
		}
	}
	
	public static String findOcc(String t) {
		if(t.indexOf(' ') != -1) {
			return t.substring(t.lastIndexOf(' '), t.length()).trim();
		} else {
			return t.trim();
		}		
	}
	
	public static String findUpgradeName(String t) {
		int s = t.indexOf(' ');
		return s != -1 ? t.substring(s, t.length()).trim() : "";
	}
	
	public static String findBuildingType(String t) {
		//System.out.println(t);
		int s = t.indexOf(".");
		return t.indexOf(".") != -1 ? t.substring(s+1, t.length()) : "";
	}

	public static int indexOf(ArrayList<ItemRow> itemList, ItemRow r) {
		// TODO Auto-generated method stub
		return 0;
	}

}
