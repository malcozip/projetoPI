package acai;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class Window{
	
	public Font font = new Font("Serif Plain", Font.BOLD, 25);
	JFrame fr;
	;
	ArrayList<JPanel> buttons = new ArrayList<>();
	JPanel telaInicial, menu, carrinho, pagamento, barraToque, barraCarrinho, barraPagamento, 
			itemCount, logoHeader, logoHeader2, menuAcai, menuBebida, menuSalgado;
	LPanel precoCarrinho = new LPanel("R$00,00", 100,25, LPanel.LEFT);
	LPanel prosseguirPag = new LPanel("Finalizar pedido", 280,50, LPanel.LEFT);
	LPanel vazio = new LPanel("Carrinho vazio",100,25,LPanel.LEFT);
	LPanel carrinhoTotal = new LPanel("Total: R$0",150,50,LPanel.LEFT);
	LPanel clearCart = new LPanel("Esvaziar carrinho", 130,28, LPanel.LEFT);
	JScrollPane scroll0, scroll1, scroll2;
	ItemRow test;
	;
	ArrayList<ItemRow> itemList = new ArrayList<>();
	ArrayList<ItemScreen> itemScreens = new ArrayList<>();
	ArrayList<JScrollPane> itemScrolls = new ArrayList<>();
	
	ArrayList<ItemScreen> listCarrinho = new ArrayList<>();
	ArrayList<carrinhoItem> carrinhoItens = new ArrayList<>();
	;
	MenuLateral menuLateral = new MenuLateral();
	Cardapio cardapio = new Cardapio();
	;
	Arrow arrowback = new Arrow();
	String[] imgIds = {"açai_correndo", "copo1", "copo2jpg", "frutinhas", "frutinhas", "logo", "shopping_cart", "plus_minus"};
	ImageIcon[] images = new ImageIcon[imgIds.length];
	JPanel[] imgContainers = new JPanel[imgIds.length];
	JPanel lastMenu;
	int[][] imageBounds = {
			{0,415,100,100}, //  [0] Açaí correndo 
			{125,185,260,260}, // [1] Copo 1
			{145,220,125,125}, // [2] Copo 2
			{75,240,160,160}, // [3] Frutinhas
			{250,250,160,160}, // [4] Frutinhas
			{185,30,130,130},  // [5] Logo
			{0,0,40,40},       //  [6] Carrinho de compras 
			{0,0,200,112}      // [7] Mais e menos 
	};
	static Color roxo = new Color(107, 24, 171), 
		  cinza = new Color(197, 191, 201);
	int itemTotal = 0, precoTotal = 0;
	public static final int INICIO = 0, MENU = 1, CARRINHO = 2, PAGAMENTO = 3;
	public static final int ACAI = 0, BEBIDA = 1, SALGADO = 2;

	private void init() {
		telaInicial = new JPanel();
		menu = new JPanel();
		carrinho = new JPanel();
		pagamento = new JPanel();
		barraToque = new JPanel();
		barraCarrinho = new JPanel();
		barraPagamento = new JPanel();
		itemCount = new JPanel((LayoutManager) new FlowLayout(FlowLayout.CENTER));
		logoHeader = new JPanel();
		logoHeader2 = new JPanel();
		menuAcai = new JPanel();
		menuBebida = new JPanel();
		menuSalgado = new JPanel();
	}
	
	public Window() {
		init();
		
		fr = new JFrame();
		fr.setTitle("Totem de açaí");
		fr.setSize(550, 700);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fr.setLocationRelativeTo(null);
		fr.setResizable(false);
		fr.getContentPane().setBackground(roxo);
		fr.setLayout(null);
		
		telaInicial.setLayout(null);
		telaInicial.setBounds(12, 12, fr.getWidth()-40, fr.getHeight()-63);
		telaInicial.setBackground(cinza);
		fr.add(telaInicial);
		
		barraToque.setBackground(roxo);
		barraToque.setLayout(null);
		barraToque.setBounds(0, 500, 510, 137);
		barraToque.setBorder(BorderFactory.createLineBorder(roxo.darker(), 3));
		JPanel logoHolder = new JPanel();
		logoHolder.setBounds(25,25,75,85);
		logoHolder.setOpaque(false);
		ImageIcon logo2 = new ImageIcon(getClass().getResource("/res/logo.png"));
		logo2.setImage(logo2.getImage().getScaledInstance(75, 75, Image.SCALE_SMOOTH));
		logoHolder.add(new JLabel(logo2));
		barraToque.add(logoHolder);
		
		LPanel toqueMsg = new LPanel("Toque para iniciar", 280, 50, LPanel.LEFT);
		toqueMsg.setBounds(145, 45);
		toqueMsg.setStyle(Font.BOLD, 25);
		
		barraToque.add(toqueMsg);
		barraToque.setName("barraToque");
		barraToque.addMouseListener(shade);
		barraToque.addMouseListener(ml);
		telaInicial.add(barraToque);
		
		logoHeader.setOpaque(false);
		logoHeader.setBorder(BorderFactory.createLineBorder(Color.gray));
		logoHeader.setBounds(-25, 0, 550, 83);
		logoHeader.add(new JLabel(logo2));
		logoHeader2.setOpaque(false);
		logoHeader2.setBorder(BorderFactory.createLineBorder(Color.gray));
		logoHeader2.setBounds(-25, 0, 550, 83);
		logoHeader2.add(new JLabel(logo2));
		
		menu.setLayout(null);
		menu.setBounds(12, 12, fr.getWidth()-40, fr.getHeight()-63);
		menu.setBackground(cinza);
		fr.add(menu);
		
		carrinho.setLayout(null);
		carrinho.setBounds(12, 12, fr.getWidth()-40, fr.getHeight()-63);
		carrinho.setBackground(cinza);
		fr.add(carrinho);
		
		for(int i = 0; i < imgIds.length; i++) {
			images[i] = new ImageIcon(getClass().getResource("/res/" + imgIds[i] + ".png"));
			images[i].setImage(images[i].getImage().getScaledInstance(imageBounds[i][2], imageBounds[i][3], Image.SCALE_SMOOTH));
			
			JPanel p = new JPanel();
			p.setOpaque(false);
			p.add(new JLabel(images[i]));
			imgContainers[i] = p;
			telaInicial.add(imgContainers[i]);
		}
		
		for(JPanel p : imgContainers) {
			int i = Ut.indexOf(imgContainers, p);
			p.setBounds(imageBounds[i][0],imageBounds[i][1],imageBounds[i][2],(i>=5)?imageBounds[i][3]+20:imageBounds[i][3]);
			if(imageBounds[i][0] == 0 && imageBounds[i][1] == 0) p.setVisible(false);
		}
		
		barraCarrinho.setBackground(roxo.brighter());
		barraCarrinho.setBorder(BorderFactory.createLineBorder(roxo, 3));
		barraCarrinho.setBounds(-3, 550, 516, 97);
		barraCarrinho.setLayout(null);
		barraCarrinho.setName("barraCarrinho");
		barraCarrinho.addMouseListener(shade);
		barraCarrinho.addMouseListener(ml);
		
		barraPagamento.setBackground(roxo.brighter());
		barraPagamento.setBorder(BorderFactory.createLineBorder(roxo, 3));
		barraPagamento.setBounds(-3, 550, 516, 97);
		barraPagamento.setLayout(null);
		barraPagamento.setName("barraPagamento");
		barraPagamento.addMouseListener(shade);
		barraPagamento.addMouseListener(ml);
		
		prosseguirPag.setStyle(Font.BOLD, 22);
		prosseguirPag.setBounds(178, 19);
		barraPagamento.add(prosseguirPag);
		
		carrinhoTotal.setStyle(Font.BOLD, 18);
		carrinhoTotal.setBounds(15,500);
		carrinho.add(carrinhoTotal);
		
		vazio.setFontSize(13);
		vazio.setBounds(15, 155);
		carrinho.add(vazio);
		
		clearCart.setBounds(350,510);
		clearCart.setBackground(roxo);
		clearCart.addMouseListener(shade);
		clearCart.addMouseListener(ml);
		clearCart.setBorder(BorderFactory.createLineBorder(roxo.darker(),2));
		clearCart.label.setForeground(Color.white);
		clearCart.setOpaque(true);
		clearCart.setStyle(Font.BOLD, 15);
		clearCart.setName("clearcart");
		carrinho.add(clearCart);
		
		JPanel verSacolaMsg = new JPanel((LayoutManager) new FlowLayout(FlowLayout.LEFT));
		verSacolaMsg.setBounds(178, 25, 280, 50);
		verSacolaMsg.setOpaque(false);
		barraCarrinho.add(verSacolaMsg);
		JLabel l2 = new JLabel("Ver carrinho");
		l2.setFont(font);
		l2.setForeground(Color.black);
		verSacolaMsg.add(l2);
		
		JPanel cartHolder = new JPanel();
		cartHolder.setBounds(32, 17, 45, 45);
		cartHolder.setOpaque(false);
		ImageIcon cart = images[6];
		cart.setImage(cart.getImage().getScaledInstance(44, 44, Image.SCALE_SMOOTH));
		cartHolder.add(new JLabel(cart));
		barraCarrinho.add(cartHolder);
		JPanel circleHolder = new JPanel();
		circleHolder.setBounds(55, 5, 50, 50);
		circleHolder.setOpaque(false);
		ImageIcon circle = new ImageIcon(getClass().getResource("/res/circle.png"));
		circle.setImage(circle.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));
		circleHolder.add(new JLabel(circle));
		barraCarrinho.add(circleHolder);
		itemCount.setBounds(70, 17, 20, 20);
		itemCount.setOpaque(false);
		JLabel l3 = new JLabel(""+itemTotal);
		l3.setFont(new Font("Serif Plain", 1, 11));
		l3.setForeground(Color.white);
		itemCount.add(l3);
		barraCarrinho.add(itemCount);
		precoCarrinho.setStyle(Font.BOLD, 22);
		precoCarrinho.setBounds(400, 35);
		//precoCarrinho.setBorder(BorderFactory.createLineBorder(Color.black));
		barraCarrinho.add(precoCarrinho);
		
		menuLateral.setBounds(0, 83, 110, 467);
		menu.add(menuLateral);
		//for(JPanel c : menuLateral.getPanels()) c.setBackground(cinza);
		
		
		
		JPanel[] a = {menuAcai, menuBebida, menuSalgado};
		for(int i = 0; i < a.length; i++) {
			Color[] c = {cinza, Color.pink, Color.green};
			a[i].setBackground(cinza);
			a[i].setBounds(110, 83, 440, 466);
			a[i].setLayout(null);
			//a[i].setBorder(BorderFactory.createLineBorder(Color.gray));
			//menu.add(a[i]);
		}
		
		scroll0 = new JScrollPane(menuAcai);
		scroll1 = new JScrollPane(menuBebida);
		scroll2 = new JScrollPane(menuSalgado);
		JScrollPane[] s = {scroll0, scroll1, scroll2};
		for(int i = 0; i < s.length; i++) {	
			s[i].setBounds(110, 83, 440, 466);
			s[i].setOpaque(false);
			s[i].setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			s[i].setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			s[i].getVerticalScrollBar().setUnitIncrement(10);
			s[i].setBackground(cinza);
			//a[i].setBorder(BorderFactory.createLineBorder(Color.gray));
			menu.add(s[i]);
		}
		
		; ; ; ; ;
		
		int xI = 20, yI = 20;
		
	
		for(ItemRow r : cardapio.list) itemList.add(r);
		
		
		for(ItemRow r : itemList) {
			//Ut.p(r.getName());
			int i = r.id;
			a[i].add(r);
			r.setBounds(xI, yI + (getItemCount(a[i])-1)*(r.h+10));
			//yI += r.h + 10;
			
			ItemScreen p = new ItemScreen(i, r);
			p.setName(r.getName());
			//Ut.p(p.getName());
			itemScreens.add(p);
		}
		
		; ; ; ; ;
		
		for(int i = 0; i < itemScreens.size(); i++) {
			itemScrolls.add(new JScrollPane(itemScreens.get(i)));
			//menu.add(p);
			//Ut.p(p.getName());
			itemScreens.get(i).n=i;
			itemScreens.get(i).setVisible(false);
		}
		
		for(JScrollPane js : itemScrolls) {
			js.setBounds(110, 83, 440, 466);
			js.setBackground(cinza);
			js.setOpaque(false);
			js.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			js.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			js.getVerticalScrollBar().setUnitIncrement(10);
			menu.add(js);
		}
		
		for(ItemRow r : itemList) {
			int i = Ut.indexOf(itemList, r);
			itemScrolls.get(i).setName(r.getName());
			//Ut.p(itemScrolls.get(i).getName());
		}
		
		for(ItemScreen is : itemScreens) {
			is.addButton.addMouseListener(mlB);
		}
		
		barraCarrinho.setComponentZOrder(circleHolder, 1);
		barraCarrinho.setComponentZOrder(itemCount, 0);
		menu.add(barraCarrinho);
		//JPanel p = logoHeader;
		//p.setBounds(0, 0, 250, 250);
		carrinho.add(logoHeader2);
		menu.add(logoHeader);
		
		carrinho.add(arrowback);
		arrowback.setBounds(10, 100);
		arrowback.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				selectVis(MENU);
				selectVisMenu(Ut.indexOf(menus(), lastMenu));
			}
		});
		carrinho.add(barraPagamento);
		
		addListeners();
		selectVis(INICIO);
		fr.setVisible(true);
	}
	
	void addCarrinho(ItemScreen is) {
		int[] aa = {7,10,12};
		listCarrinho.add(is);
		precoTotal = 0;
		for(ItemScreen i : listCarrinho) {
			//Ut.p(i.getName()+": "+i.totalPreco);
			precoTotal+=(i.menuId==0)?(aa[i.tam.selected]+i.com.getInc())*i.addPanel.counter:i.origin.price*i.addPanel.counter;
		}
		//Ut.p(precoTotal);
		updatePriceTotal(precoTotal);
		itemTotal += is.addPanel.counter;
		((JLabel)itemCount.getComponent(0)).setText(""+itemTotal);
	}
	
	void drawCarrinho() {
		carrinhoItens.clear();
		carrinhoTotal.setVisible(true);
		clearCart.setVisible(true);
		for(ItemScreen i : listCarrinho) {
			carrinhoItens.add(new carrinhoItem(i));
		}
		vazio.setVisible((carrinhoItens.size()==0));
		int y = 150;
		for(int i = 0; i < carrinhoItens.size();i++) {
			carrinho.add(carrinhoItens.get(i));
			carrinhoItens.get(i).setBounds(20, y);
			y+=carrinhoItens.get(i).h+10;
		}
	}
	
	private void updatePriceTotal(int n) { precoCarrinho.setText("R$"+(n==0?"00":n)+",00"); carrinhoTotal.setText("Total: R$"+(n==0?"00":n)+",00"); }
	private JPanel[] menus() { return new JPanel[] {menuAcai, menuBebida, menuSalgado}; }
	private JScrollPane[] scrolls() { return new JScrollPane[] {scroll0, scroll1, scroll2}; }
	
	private int getItemCount(JPanel p) {
		Component[] components = p.getComponents();
		int n = 0;
		for(Component c : components) n+=c instanceof ItemRow?1:0;
		return n;
	}
	
	private SButton[] getItemRowButtons() {
		ArrayList<SButton> list = new ArrayList<>();
		for(ItemRow ir : getItemRows()) list.add(ir.addButton);
		SButton[] r = list.toArray(new SButton[list.size()]);
		return r;
	}
	
	private ItemRow[] getItemRows() {
		ArrayList<ItemRow> list = new ArrayList<>();
		JPanel[] a = {menuAcai, menuBebida, menuSalgado};
		for(JPanel p : a) {
			Component[] comps = p.getComponents();
			for(Component c : comps) if(c instanceof ItemRow) list.add(((ItemRow) c));
		}
		ItemRow[] r = list.toArray(new ItemRow[list.size()]);
		return r;
	}
	
	private ItemRow[] getItemRows(int n) {
		ArrayList<ItemRow> list = new ArrayList<>();
		JPanel[] a = {menuAcai, menuBebida, menuSalgado};
		for(Component c : a[n].getComponents()) {
			if(c instanceof ItemRow) list.add((ItemRow)c);
		}
		ItemRow[] r = list.toArray(new ItemRow[list.size()]);
		return r;
	}
	
	private JScrollPane getScroll(String t) {
		for(JScrollPane js : itemScrolls) {
			if(js.getName()!=null) if(js.getName().equals(t)) return js;
		}
		return null;
	}
	
	private void addListeners() {
		for(JPanel b : buttons) b.addMouseListener(((b instanceof SButton)?((SButton)b).ml:ml));
		for(JPanel p : menuLateral.getPanels()) p.addMouseListener(ml);
		for(SButton b: getItemRowButtons()) b.addMouseListener(ml);
	}
	
	private void selectVis(int n) {
		carrinhoTotal.setVisible(false);
		clearCart.setVisible(false);
		JPanel[] a = {telaInicial, menu, pagamento};
		for(JPanel p : a) p.setVisible((n==Ut.indexOf(a,p))?true:false);
		if(n==2) drawCarrinho();
	}
	
	private void render(int n) {
		for(JScrollPane js : itemScrolls) js.setVisible(false);
		//for(ItemScreen is : itemScreens) is.setVisible(false);
		int y = 0;
		for(ItemRow ir : getItemRows(n)) {
			ir.setBounds(20, 20 + (Ut.indexOf(getItemRows(n), ir))*(ir.h+10));
			y += ir.h+10;
		}
		if(y>=466) menus()[n].setPreferredSize(new Dimension(440, y+30));
		//Ut.p(y);
	}
	
	private void selectVisMenu(int n) {
		carrinhoTotal.setVisible(false);
		JPanel[] a = {menuAcai, menuBebida, menuSalgado};
		render(n);
		for(JPanel p : a) {
			if(scrolls()[Ut.indexOf(a, p)]!=null) scrolls()[Ut.indexOf(a, p)].setVisible((n==Ut.indexOf(a, p)));
			lastMenu = n==Ut.indexOf(a, p)?p:lastMenu;
		}
	}
	
	ChangeListener cl = new ChangeListener() {
		public void stateChanged(ChangeEvent e) {
			JPanel p = (JPanel) e.getSource();
		}
	};
	
	MouseListener ml = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			JPanel p = (JPanel) e.getSource();
			String name = p.getName();
			//Ut.p(name);
			if(name.indexOf(' ')!=-1&&name.substring(name.lastIndexOf(' ')+1).equals("SButton")) {
				String nameAlt = name.substring(0, name.length()-8);
				for(JPanel pa : itemScreens) if(pa.getName().equals(nameAlt)) {
					((ItemScreen)pa).draw();
					//Ut.p(pa.getName()+".");
				}
				return;
			}
			if(name.substring(0, name.length()-1).equals("painelLateral")) selectVisMenu(Ut.number(name));
			switch(name) {
				case "barraToque":
					selectVis(MENU);
					selectVisMenu(ACAI);
					break;
				case "barraCarrinho":
					selectVis(CARRINHO);
					break;
				case "clearcart":
					listCarrinho.clear();
					carrinhoItens.clear();
					carrinho.removeAll();
					carrinho.add(vazio);
					carrinho.add(arrowback);
					carrinho.add(logoHeader2);
					carrinho.add(barraPagamento);
					carrinho.add(carrinhoTotal);
					carrinho.add(clearCart);
					precoTotal = 0;
					itemTotal = 0;
					((JLabel)itemCount.getComponent(0)).setText(""+itemTotal);
					updatePriceTotal(precoTotal);
					selectVis(MENU);
					break;
				case "barraPagamento":
					if(carrinhoItens.size()==0) {
						Ut.p("Carrinho vazio! Adicione itens para poder finalizar sua compra.");
					} else {
						Ut.p("Compra finalizada! Total: R$" + precoTotal + ",00");
					}
					break;
				default:
					break;
			}
		}
		
		public void mouseEntered(MouseEvent e) {
			JPanel p = (JPanel) e.getSource();
			//p.setBackground(p.getBackground().darker());
			//fr.setCursor(Cursor.HAND_CURSOR);
		}
		
		public void mouseExited(MouseEvent e) {
			JPanel p = (JPanel) e.getSource();
			//p.setBackground(p.getBackground().brighter());
			//fr.setCursor(Cursor.DEFAULT_CURSOR);
		}
	};
	
	MouseListener shade = new MouseAdapter() {
		public void mouseEntered(MouseEvent e) { ((JPanel)e.getSource()).setBackground(((JPanel)e.getSource()).getBackground().darker()); fr.setCursor(Cursor.HAND_CURSOR);}
		public void mouseExited(MouseEvent e) { ((JPanel)e.getSource()).setBackground(((JPanel)e.getSource()).getBackground().brighter()); fr.setCursor(Cursor.DEFAULT_CURSOR);}
	};
	
	MouseListener mlB = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			addB b = (addB) e.getSource();
			ItemScreen is = (ItemScreen) b.getParent();
			addCarrinho(is);
			selectVisMenu(Ut.indexOf(menus(), lastMenu));
			//Ut.p(is.totalPreco);
		}
	};
	
	public class ItemScreen extends JPanel {
		ItemRow origin;
		int n = 0;
		int menuId = 0;
		int totalPreco = 0;
		Arrow arrowButton = new Arrow();
		addP addPanel = new addP();
		addB addButton = new addB();
		tamanhoPanel tam = new tamanhoPanel();
		compPanel com = new compPanel();
		IconHolder pic = new IconHolder(100,100);
		LPanel voltar = new LPanel("Voltar", 40, 10, LPanel.LEFT),
				msg1 = new LPanel("Teste", 180, 60, LPanel.LEFT),
				total = new LPanel("Total: R$0", 120, 40, LPanel.LEFT),
				complementos = new LPanel("Complementos:", 140, 40, LPanel.LEFT),
				tamanhos = new LPanel("Tamanhos:", 140, 40, LPanel.LEFT),
				preco = new LPanel("Preço: ", 140, 40, LPanel.LEFT);
		ItemScreen(int n, ItemRow o){
			super();
			this.origin = o;
			this.menuId = n;
			setName(origin.getName());
			setBackground(cinza);
			setBounds(110, 83, 440, 466);
			setLayout(null);
			setBorder(BorderFactory.createMatteBorder(1,1,1,1,Color.gray));
			
			add(arrowButton);
			arrowButton.setName("backmenu");
			arrowButton.setBounds(10, 10);
			arrowButton.addMouseListener(m1);
			
			add(voltar);
			voltar.setBounds(40, 20);
			
			msg1.setStyle(Font.BOLD, 25);
			//msg1.setBorder(getBorder());
			msg1.setBounds(130, 77);
			msg1.setText(origin.getName());
			add(msg1);
			
			pic.setBounds(15,60);
			pic.setOpaque(false);
			pic.setBorder(BorderFactory.createLineBorder(new Color(194,196,194)));
			pic.c = origin.ih.c;
			pic.init();
			pic.removeMouseListener(pic.ml);
			add(pic);
			
			addPanel.setBounds(20,170);
			add(addPanel);
			for(SButton b : addPanel.getButtons()) b.addMouseListener(new MouseAdapter() {public void mouseClicked(MouseEvent e) {
				updateTotal();
				}});
			for(JPanel p : tam.getPanels()) p.addMouseListener(new MouseAdapter() {public void mouseClicked(MouseEvent e) {
				updateTotal();
				}});
			add(total);
			//total.setBorder(BorderFactory.createLineBorder(Color.gray));
			total.setStyle(Font.BOLD,14);
			
			add(addButton);
			add(preco);
			preco.setStyle(Font.BOLD,14);
			preco.setText("Preço: R$"+(origin.price==(int)origin.price?(int)origin.price:(""+origin.price).substring(0, (""+origin.price).indexOf('.')))+",00");
			
			switch(menuId) {
			case 0:
				add(complementos);
				complementos.setStyle(Font.BOLD,17);
				add(com);
				add(tamanhos);
				tamanhos.setStyle(Font.BOLD,17);
				add(tam);
				for(JPanel p : com.getPanels()) p.addMouseListener(new MouseAdapter() {public void mouseClicked(MouseEvent e) {
					updateTotal();
					}});
				break;
			case 1:
				break;
			case 2:
				break;
			}
		}
		
		
		void updateTotal() {
			totalPreco = totalPreco + (int) (origin.price*addPanel.counter);
			
			if(addPanel.counter==0) {		
				total.setText("Total: R$0");
				return;
			}
			if(menuId==0) {
				double[] prices = {7,10,12};
				double pr = prices[tam.selected]*addPanel.counter+com.getInc()*addPanel.counter;
				totalPreco = (int) pr;
				//Ut.p(com.getInc());
				String s = (""+pr);
				total.setText("Total: R$"+s.substring(0, s.indexOf('.'))+",00");
				return;
			}
			total.setText("Total: R$"+(""+(int)(origin.price*addPanel.counter))+",00");
		}
		
		void draw() {
			int y = 245;
			addPanel.counter=0;
			addPanel.updateCounter();
			updateTotal();
			com.reset();
			
			if(menuId==0) {
				tamanhos.setBounds(21, y);
				y+=tamanhos.h;				
				tam.setBounds(20, y);
				y+=tam.h;
				
				complementos.setBounds(21, y);
				y+=complementos.h;
				com.setBounds(20, y);
				y+=com.h+10;
			} else {
				preco.setBounds(130, 120);
			}
			
			total.setBounds(20, y);
			y+=total.h+15;
			
			addButton.setBounds(20,y);
			y+=addButton.h;
			
			if(y>=466) setPreferredSize(new Dimension(440,y+30));
			
			itemScrolls.get(n).setVisible(true);
			//Ut.p(origin.getName());
			setVisible(true);
			scrolls()[Ut.indexOf(menus(), lastMenu)].setVisible(false);
		}
		
		MouseListener m1 = new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				fr.setCursor(Cursor.HAND_CURSOR);
			}
			public void mouseExited(MouseEvent e) {
				fr.setCursor(Cursor.DEFAULT_CURSOR);
			}
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				selectVisMenu(Ut.indexOf(menus(), lastMenu));
			}
		};
		
	}
	
	private class tamanhoPanel extends JPanel {
		int w=270, h=130, selected = 0;
		JPanel cb = new JPanel(), cb1 = new JPanel(), cb2 = new JPanel();
		LPanel peq = new LPanel("Pequeno (R$7)", 130,16,LPanel.LEFT),  med = new LPanel("Médio (R$10)", 130,16,LPanel.LEFT), gra = new LPanel("Grande (R$12)", 130,16,LPanel.LEFT);
		tamanhoPanel(){
			super();
			setLayout(null);
			setOpaque(false);
			//setBorder(BorderFactory.createLineBorder(Color.black));
			
			JPanel[] a = {cb, cb1, cb2};
			for(int i = 0; i < a.length; i++) {
				add(a[i]);
				a[i].setBackground(cinza);
				a[i].setBorder(BorderFactory.createLineBorder(Color.black,2));
				a[i].setBounds(170, 10+i*35, 25, 25);
				a[i].addMouseListener(thism);
			}
			cb.setBackground(Color.black);
			
			LPanel[] a1 = {peq,med,gra};
			for(LPanel lp : a1) {
				lp.setBounds(20, 12+Ut.indexOf(a1, lp)*35);
				lp.setStyle(Font.BOLD, 15);
				add(lp);
			}
			
		}
		JPanel[] getPanels() {return new JPanel[] {cb,cb1,cb2};}
		void setBounds(int x, int y) {setBounds(x,y,w,h);}
		
		MouseListener thism = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				JPanel[] a = {cb, cb1, cb2};
				for(JPanel p1 : a) {
					if(p==p1) {
						//Ut.p("sad");
						selected = Ut.indexOf(a, p1);
						//Ut.p(selected);
						p.setBackground(Color.black);
					} else p1.setBackground(cinza);
					
				}
			}
			public void mouseEntered(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				fr.setCursor(Cursor.HAND_CURSOR);
			}
			public void mouseExited(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				fr.setCursor(Cursor.DEFAULT_CURSOR);
			}
		};
	}
	
	private class compPanel extends JPanel {
		int w=310, h=130, selected = 0;
		JPanel cb = new JPanel(), cb1 = new JPanel(), cb2 = new JPanel();
		LPanel peq = new LPanel("Banana (+R$2)", 160,16,LPanel.LEFT),  med = new LPanel("Leite Condensado (+R$3)", 185,16,LPanel.LEFT), gra = new LPanel("Leite Ninho (+R$3)", 160,16,LPanel.LEFT);
		IconHolder ih0 = new IconHolder(25,25), ih1 = new IconHolder(25,25), ih2 = new IconHolder(25,25);
		compPanel(){
			super();
			setLayout(null);
			setOpaque(false);
			//setBorder(BorderFactory.createLineBorder(Color.black));
			
			JPanel[] a = {cb, cb1, cb2};
			for(int i = 0; i < a.length; i++) {
				add(a[i]);
				a[i].setBackground(cinza);
				a[i].setBorder(BorderFactory.createLineBorder(Color.black,2));
				a[i].setBounds(250, 10+i*35, 25, 25);
				a[i].addMouseListener(thism);
			}
			
			IconHolder[] ihs = {ih0, ih1, ih2};
			ih0.c = ih0.banana;
			ih1.c = ih1.leitemoca;
			ih2.c = ih2.leiteninho;
			for(IconHolder i : ihs) {
				int n = Ut.indexOf(ihs, i);
				int t = n==2?32:25;
				i.c.setImage(i.c.getImage().getScaledInstance(t, t, 4));
				i.init();
				add(i);
				i.setBounds(20, 10+n*35);
			}
			
			LPanel[] a1 = {peq,med,gra};
			for(LPanel lp : a1) {
				//lp.setBorder(BorderFactory.createLineBorder(Color.black));
				lp.setBounds(60, 12+Ut.indexOf(a1, lp)*35);
				lp.setStyle(Font.BOLD, 15);
				add(lp);
			}
			
		}
		JPanel[] getPanels() {return new JPanel[] {cb,cb1,cb2};}
		void reset() {for(JPanel p : getPanels()) p.setBackground(cinza);;}
		int getInc() {
			int r = 0;
			if(cb.getBackground()==Color.black) r += 2;
			if(cb1.getBackground()==Color.black) r += 3;
			if(cb2.getBackground()==Color.black) r += 3;
			return r;
		}
		void setBounds(int x, int y) {setBounds(x,y,w,h);}
		MouseListener thism = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				p.setBackground(p.getBackground()!=Color.black?Color.black:cinza);
			}
			public void mouseEntered(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				fr.setCursor(Cursor.HAND_CURSOR);
			}
			public void mouseExited(MouseEvent e) {
				JPanel p = (JPanel) e.getSource();
				fr.setCursor(Cursor.DEFAULT_CURSOR);
			}
		};
	}
	
	private class addB extends JPanel {
		int w = 210, h = 35;
		LPanel msg = new LPanel("Adicionar item", 110,20, LPanel.LEFT);
		addB(){
			super();
			setLayout(null);
			setBackground(roxo);
			setBorder(BorderFactory.createLineBorder(roxo.darker(),3));
			addMouseListener(shade);
			
			msg.setBounds(10, 7);
			msg.label.setForeground(Color.white);
			msg.setFontSize(15);
			msg.setFontStyle(Font.BOLD);
			add(msg);
		}
		void setBounds(int x,int y) {setBounds(x,y,w,h);}
	}
	
	private class addP extends JPanel {
		int w= 350, h= 60, counter = 0;
		LPanel qntd = new LPanel("Quantidade: ", 150,40,LPanel.LEFT);
		SButton minus = SButton.minus(10), plus = SButton.plus(10);
		LPanel count = new LPanel("0", 25, 25, LPanel.LEFT);
		addP() {
			super();
			setOpaque(false);
			setLayout(null);
			//setBorder(BorderFactory.createLineBorder(Color.gray.darker()));
			
			count.setBounds(279,17);
			//count.setBorder(BorderFactory.createLineBorder(Color.gray.darker()));
			count.setFontSize(19);
			
			qntd.setBounds(10,10);
			//qntd.setBorder(BorderFactory.createLineBorder(Color.gray.darker()));
			qntd.setStyle(Font.BOLD, 17);
			
			minus.setBounds(235, 13);
			minus.setName("-");
			minus.addMouseListener(thism);
			plus.setName("+");
			plus.addMouseListener(thism);
			plus.setBounds(305,13);
			
			add(qntd);
			add(minus);
			add(plus);
			add(count);
			//qntd.setVisible(true);
			updateCounter();
		}
		SButton[] getButtons() {return new SButton[] {plus, minus};}
		void setBounds(int x, int y) {setBounds(x, y, w, h);}
		void updateCounter() { count.setText(""+counter); }
		MouseListener thism = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				Component c = (Component) e.getSource();
				counter+=c.getName().equals("+")?counter<10?1:0:counter>0?-1:0;
				updateCounter();
			}
		};
	}
	
	class carrinhoItem extends JPanel{
		int w=400, h=80;
		ItemScreen is;
		IconHolder icon;
		LPanel qnt = new LPanel("",100,50,LPanel.LEFT);
		LPanel nome = new LPanel("",150,50,LPanel.LEFT);
		carrinhoItem(ItemScreen i){
			super();
			this.is = i;
			setLayout(null);
			setOpaque(false);
			setBorder(BorderFactory.createLineBorder(Color.gray));
			
			icon = new IconHolder(60,60);
			icon.c = is.origin.ih.c;
			icon.init();
			icon.removeMouseListener(icon.ml);
			icon.c.setImage(icon.c.getImage().getScaledInstance(60, 60, 4));
			icon.setBounds(10, 10);
			
			nome.setText(is.origin.name);
			nome.setStyle(Font.BOLD, 16);
			//nome.setBorder(BorderFactory.createLineBorder(Color.black));
			nome.setBounds(75, 10);
			
			qnt.setText("Qntd: "+is.addPanel.counter);
			qnt.setStyle(Font.BOLD, 16);
			//qnt.setBorder(BorderFactory.createLineBorder(Color.black));
			qnt.setBounds(245,10);
			
			add(icon);
			add(qnt);
			add(nome);
		}
		void setBounds(int x, int y) {setBounds(x,y,w,h);}
	}
}